print("Hello World!")   #1


name = "Kyle"   #2
print("Hello", name,"!")#leaves space between name and !
print("Hello"+name+"!")#No spaces
#print("Hello", name + "!")#Not ninja bonus worthy, but still just right


name = 42   #3
print("Hello", name, "!")
print("Hello"+name+"!")#error



fav_food1 = "sushi" #4
fav_food2 = "pizza"

print("I love to eat {} and {}.".format(fav_food1, fav_food2))
print(f"I love to eat {fav_food1} and {fav_food2}.")
