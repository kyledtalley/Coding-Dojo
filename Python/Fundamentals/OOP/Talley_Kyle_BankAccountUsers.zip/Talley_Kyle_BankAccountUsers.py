class BankAccount:
    bank_name = "NewBank"

    def __init__(self, ir):
        self.ir = ir


    def yield_interest(self):
        if self.balance > 0.00:
            self.balance = self.account.BankAccount.balance * (1 + self.ir)
            print(f"{self.name}'s yield has made their wallets too big for their pockets!")
        else:
            print(f"No large enough balance present to yield interest for for account holder: {self.name}")

#I honestly don't know why we are making two classes if one can do everything, not sure how to combine them. Moved most of stuff over to User class. I shall have to ask my cohorts, because I can see the great ability in it. We are going over stuff like this in class today so it should help. I will likely have to redo this



class User:
    bank_name = "NewBank"

    def __init__(self, name, checkings, savings, email):
        self.name = name
        self.checkings = checkings
        self.savings = savings
        self.email = email
        self.balance = (self.checkings + self.savings)


        print(f"\nWelcome {self.name}.")
        print(f"\nYou have entered ${self.checkings} as your checking account, ${self.savings} as your savings account, and you have registered {self.email} as your email on file.\n")
        print(f"\nYour balance is {self.balance}.")

    def display_account_info(self):
        print(f"{self.name}'s balance: ${self.balance}")


    def deposit(self,checkingamount,savingsamount):
        print(f"Please enter the amount of money you would like to initialize your account with in your checkings.\nYou have entered ${checkingamount}.")
        self.checkings += checkingamount
        print(f"Please enter the amount of money you would like to add into your savings account\nYou have entered ${savingsamount}.")
        self.savings += savingsamount

    def display_account_info(self):
        print(f"{self.name}'s balance: ${self.balance}\nChecking Account Balance: {self.checkings}\nSavings Account Balance: {self.savings}")


    def get_account_info(self):
        print(f"User Info:\nName: {self.name}\nEmail: {self.email}\nAccount Balance: {self.balance}\n Checkings: {self.checkings}\n Savings: {self.savings}\n")



Kyle = User("Kyle", 1928.11, 282.90, "kyletalley@me.com")

Kyle.deposit(299.20, 426.12)

Kyle.get_account_info()
