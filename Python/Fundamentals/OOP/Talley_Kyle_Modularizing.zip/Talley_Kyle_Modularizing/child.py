import parent

print(__name__)
