package com.codingdojo.dojosandninjas2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojosAndNinjas2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
