package com.codingdojo.JavaExamPrep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaExamPrepApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaExamPrepApplication.class, args);
	}

}
