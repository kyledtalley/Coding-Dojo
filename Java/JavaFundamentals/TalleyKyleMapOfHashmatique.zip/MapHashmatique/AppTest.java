

public class AppTest {
    public static void main(String[] args) {
        SoundTrack test = new SoundTrack();
        test.setList();
    }
}
