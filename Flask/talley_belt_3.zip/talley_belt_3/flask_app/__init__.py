from flask import Flask
# creates our flask app
app = Flask(__name__)
app.secret_key = "cellar door"
