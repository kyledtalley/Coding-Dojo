I'm pretty happy with this one! The errors I see that I couldn't figure out how to fix (that always work in my other projects) were:
*second column of index is not showing up for some reason
*Welcome session user_id! is not working. I've ran into this problem before but couldn't figure out how to fix it this time.

I hope you like my car website!
