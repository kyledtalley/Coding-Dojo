from flask_app.controllers import friends
from flask_app import app


#I am going to work on this more. Right now I feel like the update and delete functions should be working but they're not. However, Creating and Reading work great.
if __name__=="__main__":
    app.run(debug=True)
