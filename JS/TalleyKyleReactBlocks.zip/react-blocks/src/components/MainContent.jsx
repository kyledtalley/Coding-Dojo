const Main = () => {
	return (
		<>
			<h1 className="main">
				<div>
					<h1 className="subContent"></h1>
					<h1 className="subContent"></h1>
					<h1 className="subContent"></h1>
				</div>
				<div>
					<h1 className="advertisement"></h1>
				</div>
			</h1>
		</>
	)
}

export default Main
