const Navigation = () => {


	return (
		<>
			<div className = "side-nav">

			</div>
		</>
	)
}

export default Navigation
