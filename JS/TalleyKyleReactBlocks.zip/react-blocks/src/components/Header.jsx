const Header = () =>
{
	return(
	<div className = "header">

	</div>
	)
}
export default Header
