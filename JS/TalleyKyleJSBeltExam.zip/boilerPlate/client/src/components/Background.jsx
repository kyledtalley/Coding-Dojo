import React from 'react';
import './Background.css';

const Background = () => {
  return (
    <div className="background">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
    </div>
  );
};

export default Background;
