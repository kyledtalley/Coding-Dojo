import React, { useState } from 'react'
import "./App.css"
import Form from './components/Form'
const App = () => {
  return (
    <>

      <Form/>


    </>
  )
}

export default App
