
import './App.css'

function App() {
  return (
    <>
      <div className = "form-group">
          <h1 style={{fontSize:"100x"}}>
            Hello Dojo!
          </h1>
          <h3 >Things I need to do:</h3>
          <h5>*Learn React</h5>
          <h5>*Climb Mt. Everest</h5>
          <h5>*Run a marathon</h5>
          <h5>*Feed the dogs</h5>
      </div>

    </>
  )
}

export default App
