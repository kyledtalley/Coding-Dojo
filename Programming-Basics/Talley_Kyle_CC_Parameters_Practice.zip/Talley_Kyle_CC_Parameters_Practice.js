function helloThere(name, time){
  console.log("I'm coming for you "+ name + time);

}

var enemy = "Darth Grogu";
var time = ", right now!";

helloThere(enemy,time);
