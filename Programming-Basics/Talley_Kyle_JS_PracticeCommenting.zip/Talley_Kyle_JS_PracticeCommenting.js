// This variable holds the number of likes
var likeCount = 0;
// This function of the codeblock will add one like to the variable likeCount
function increaseLikes() {
    // This operation is a mathematical operatoin adding 1 "like" to the likeCount
    likeCount = likeCount + 1;
}
