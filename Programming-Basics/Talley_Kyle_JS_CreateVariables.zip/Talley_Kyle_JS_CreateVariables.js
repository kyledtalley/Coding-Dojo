//variables for our program to determien if a guest can ride the coaster
var minimum_age = 10;//in years
var minimum_height = 42;//in inches
 console.log("You must be", minimum_age, "years old, and", minimum_height, "inches tall to ride this roller coaster.");

